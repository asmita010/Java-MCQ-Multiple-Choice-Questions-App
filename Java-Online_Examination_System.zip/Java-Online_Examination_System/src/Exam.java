import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;

import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.border.BevelBorder;

import net.proteanit.sql.DbUtils;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ScrollPaneConstants;
import javax.swing.UIManager;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.ListSelectionModel;

public class Exam {

	 JFrame frame;
	 final JLabel lblNewLabel = new JLabel("");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Exam window = new Exam();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Exam() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBackground(new Color(255, 255, 255));
		frame.setBounds(0, 0,1362 , 725);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(6, 6, 1342, 680);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_5 = new JLabel("Questions");
		lblNewLabel_5.setForeground(new Color(255, 255, 153));
		lblNewLabel_5.setFont(new Font("SansSerif", Font.PLAIN, 25));
		lblNewLabel_5.setBounds(327, 157, 146, 34);
		panel.add(lblNewLabel_5);
		
		JButton timer = new JButton("Set Time");
		timer.setForeground(new Color(102, 0, 102));
		timer.setFont(new Font("Lucida Sans", Font.BOLD, 18));
		timer.setIcon(new ImageIcon(Exam.class.getResource("/image/Time-Management-icon (1).png")));
		timer.setBounds(927, 571, 197, 46);
		panel.add(timer);
		
		JLabel lblNewLabel_4 = new JLabel("list and click on Buttton");
		lblNewLabel_4.setBackground(new Color(245, 245, 245));
		lblNewLabel_4.setForeground(new Color(255, 255, 153));
		lblNewLabel_4.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 22));
		lblNewLabel_4.setBounds(904, 178, 316, 46);
		panel.add(lblNewLabel_4);
		
		JButton btnNewButton = new JButton("Go Back To Main Page");
		
		btnNewButton.setFont(new Font("SansSerif", Font.BOLD, 16));
		btnNewButton.setIcon(new ImageIcon(Exam.class.getResource("/image/go-back-icon (1).png")));
		btnNewButton.setBounds(39, 15, 240, 35);
		panel.add(btnNewButton);
		
		JLabel lblNewLabel_3 = new JLabel("Select Exam from Drop-down\r\n");
		lblNewLabel_3.setBackground(new Color(250, 240, 230));
		lblNewLabel_3.setForeground(new Color(255, 255, 153));
		lblNewLabel_3.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 22));
		lblNewLabel_3.setBounds(866, 134, 403, 57);
		panel.add(lblNewLabel_3);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(49, 208, 717, 438);
		panel.add(scrollPane);
		
		JList list = new JList();
		list.setForeground(Color.BLACK);
		list.setValueIsAdjusting(true);
		scrollPane.setViewportView(list);
		list.setVisibleRowCount(10);
		list.setBackground(new Color(224, 255, 255));
		list.setFont(new Font("Lucida Sans", Font.BOLD, 20));
		list.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		
		
		JButton b4 = new JButton("Add new Exam");
		b4.setForeground(new Color(102, 0, 102));
		b4.setIcon(new ImageIcon(Exam.class.getResource("/image/Button-Add-icon.png")));
		b4.setFont(new Font("Lucida Sans", Font.BOLD, 18));
		b4.setBounds(927, 461, 220, 46);
		panel.add(b4);
		
		JButton b3 = new JButton("Delete Exam");
		b3.setForeground(new Color(102, 0, 102));
		b3.setFont(new Font("Lucida Sans", Font.BOLD, 18));
		b3.setIcon(new ImageIcon(Exam.class.getResource("/image/Button-Close-icon.png")));
		b3.setBounds(927, 343, 211, 46);
		panel.add(b3);
		
		JButton b1 = new JButton("Show Questions");
		b1.setIcon(new ImageIcon(Exam.class.getResource("/image/Start-Menu-Search-icon.png")));
		b1.setForeground(new Color(128, 0, 0));
		b1.setFont(new Font("Lucida Sans", Font.BOLD, 20));
		b1.setBounds(963, 77, 248, 40);
		panel.add(b1);
		
		JButton b2 = new JButton("Change Exam Name");
		b2.setForeground(new Color(102, 0, 102));
		b2.setFont(new Font("Lucida Sans", Font.BOLD, 18));
		b2.setIcon(new ImageIcon(Exam.class.getResource("/image/Button-Next-icon.png")));
		b2.setBounds(904, 236, 264, 46);
		panel.add(b2);
		
		JComboBox c = new JComboBox();
		
		c.setBackground(new Color(255, 255, 224));
		c.setBounds(248, 80, 647, 37);
		c.setFont(new Font("Andalus", Font.PLAIN, 20));
		panel.add(c);
		
		JLabel lblNewLabel_2 = new JLabel("Select Exam");
		lblNewLabel_2.setBackground(new Color(255, 250, 240));
		lblNewLabel_2.setBounds(49, 76, 237, 41);
		lblNewLabel_2.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 25));
		lblNewLabel_2.setForeground(new Color(255, 255, 153));
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setFont(new Font("Lucida Sans", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(0, 0, 1342, 680);
		lblNewLabel_1.setIcon(new ImageIcon(Exam.class.getResource("/image/imgonline-com-ua-resize-CoDsdEXtEM0mx.jpg")));
		panel.add(lblNewLabel_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(50, 179, 717, 438);
		panel.add(panel_1);
		panel_1.setLayout(null);
		

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st=con.createStatement();
			String sql = "select examname from mexam";
			ResultSet r=st.executeQuery(sql);
			
		    while (r.next()){
			c.addItem(r.getString(1));
		    }
		   st.close();
		   con.close();
		    }
			catch(Exception e)
			{
				e.printStackTrace();
			}
		try {
			 String a = (String) c.getItemAt(c.getSelectedIndex());
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con2=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st2=con2.createStatement();
			String sql = "select actualquestion from mquestion q,mexam e where q.examid=e.examid and examname='"+a+"'";
			ResultSet r=st2.executeQuery(sql);
			DefaultListModel dlm=new DefaultListModel();
		    while (r.next()){
			dlm.addElement(r.getString(1));
		    }
		    list.setModel(dlm);
		    st2.close();
			   con2.close();
		    }
			catch(Exception e)
			{
				e.printStackTrace();
			}
		
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
					 String a = (String) c.getItemAt(c.getSelectedIndex());
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con3=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
					Statement st3=con3.createStatement();
					String sql = "select actualquestion from mquestion q,mexam e where q.examid=e.examid and examname='"+a+"'";
					ResultSet r=st3.executeQuery(sql);
					DefaultListModel dlm=new DefaultListModel();
				    while (r.next()){
					dlm.addElement(r.getString(1));
				    }
				    list.setModel(dlm);
				    st3.close();
					   con3.close();
				    }
					catch(Exception ea)
					{
						ea.printStackTrace();
					}
			}
		});
		
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s = (String) c.getItemAt(c.getSelectedIndex());
				
			
				

			  String m=JOptionPane.showInputDialog(frame,  "Change Name of Exam'"+s+"'", JOptionPane.QUESTION_MESSAGE);

				if(m==null)
				{
					return ;
				}
				else
				{
				  try {
						Class.forName("oracle.jdbc.driver.OracleDriver");
						Connection con4=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
						String sql = "update mexam set examname='"+m+"' where examname='"+s+"'";
						PreparedStatement st4=con4.prepareStatement(sql);
						int count=st4.executeUpdate();
						
						st4.close();
						   con4.close();
					 
					    }
						catch(Exception ea)
						{
							ea.printStackTrace();
						}
					
				  try {
						c.removeAllItems();
						Class.forName("oracle.jdbc.driver.OracleDriver");
						Connection con5=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
						Statement st5=con5.createStatement();
						String sql = "select examname from mexam";
						ResultSet r=st5.executeQuery(sql);
						
					    while (r.next()){
						c.addItem(r.getString(1));
					    }
					    st5.close();
						   con5.close();
					    }
						catch(Exception se)
						{
							se.printStackTrace();
						}
		  }
		  
			}
			});
		
		
		b3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String s = (String) c.getItemAt(c.getSelectedIndex());
				
				int result = JOptionPane.showConfirmDialog(frame,"Question and OPTIONS will also be deleted from Exam '"+s+"'.", "Delete Exam",
			               JOptionPane.YES_NO_OPTION,
			               JOptionPane.ERROR_MESSAGE);
				
				if(result == JOptionPane.YES_OPTION){
		                try {
						Class.forName("oracle.jdbc.driver.OracleDriver");
						Connection con6=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
						Connection con7=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
						Connection con8=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
						Connection con9=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");

						String que="delete moption where questionid in (select questionid from mquestion where examid in(select examid from mexam where examname='"+s+"'))";
						String query="delete  mquestion where examid in(select examid from mexam where examname='"+s+"')";
						String quer="delete mresult where examid in (select examid from mexam where examname='"+s+"')";
						String q="delete mexam where examname='"+s+"'";
						
						PreparedStatement st6=con6.prepareStatement(que);
						PreparedStatement st7=con7.prepareStatement(query);
						PreparedStatement st8=con8.prepareStatement(quer);
						PreparedStatement st9=con9.prepareStatement(q);

						int c=st6.executeUpdate();
						int co=st7.executeUpdate();
						int cou=st8.executeUpdate();
						int coun=st9.executeUpdate();
					
							st6.close();
						   con6.close();
						   st7.close();
						   con7.close();
						   st8.close();
						   con8.close();
						   st9.close();
						   con9.close();
					    }
						catch(Exception ea)
						{
							ea.printStackTrace();
						}
		                try {
							c.removeAllItems();
							Class.forName("oracle.jdbc.driver.OracleDriver");
							Connection con9=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
							Statement st9=con9.createStatement();
							String sql = "select examname from mexam";
							ResultSet r=st9.executeQuery(sql);
							
						    while (r.next()){
							c.addItem(r.getString(1));
						    }
						    st9.close();
							   con9.close();
						    }
							catch(Exception e)
							{
								e.printStackTrace();
							}
	           
	            }
	           
	           
			   
				  }
			
		});
		
	
	
	
		
	
	
		
		b4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
		
				String m=JOptionPane.showInputDialog(frame, "Enter Exam to be created");  
				if(m==null)
				{
					return ;
				}
				else
				{
			     try
			     {
			     String url="jdbc:oracle:thin:@localhost:1521:xe";
					String username="username";
					String password="password";
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con10 = DriverManager.getConnection(url,username,password);

					String query="insert into mexam values(smexamid.nextval,'"+m+"',null)";   
					PreparedStatement st10=con10.prepareStatement(query);
					int count=st10.executeUpdate();
					st10.close();
					   con10.close();
				}
			     catch(Exception ea)
			     {
			    	 ea.printStackTrace();
			     }
			     try {
						c.removeAllItems();
						Class.forName("oracle.jdbc.driver.OracleDriver");
						Connection con11=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
						Statement st11=con11.createStatement();
						String sql = "select examname from mexam";
						ResultSet r=st11.executeQuery(sql);
						
					    while (r.next()){
						c.addItem(r.getString(1));
					    }
					    st11.close();
						   con11.close();
					    }
						catch(Exception e)
						{
							e.printStackTrace();
						}
			}
			}
		});
		
		timer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String s=(String) c.getItemAt(c.getSelectedIndex());

				String m=JOptionPane.showInputDialog(frame, "Enter Time (in Minutes) for Exam "+s);  
				if(m==null)
				{
					return ;
				}
				else
				{
			
			     try
			     {
			    	 int c=0;
			    	 for (int i=0;i<=9;i++) {
							String str1=Integer.toString(i);
							if(m.contains(str1))
								c=1;
					}
				if (c==0)
				{
					  JOptionPane.showMessageDialog(frame,"Please Enter Time in Numeric form", "Invlaid Entry", JOptionPane.ERROR_MESSAGE);
					}
				else {
			     String url="jdbc:oracle:thin:@localhost:1521:xe";
					String username="username";
					String password="password";
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con10 = DriverManager.getConnection(url,username,password);

					String query="update mexam set time='"+m+"' where examname='"+s+"'";   
					
					PreparedStatement st10=con10.prepareStatement(query);

					int count=st10.executeUpdate();
					
					st10.close();
					   con10.close();
				}
			     }
			     catch(Exception ea)
			     {
			    	 ea.printStackTrace();
			     }
				
				}
			}
		});
	
		
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				Ones2 ob=new Ones2();
				ob.frame1.setVisible(true);
			}
		});
		
		
		
		
	}
}
