import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Window;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JPasswordField;

public class Ones1 {
	
	public JFrame frame1;
	private JTextField t1;
	private JTextField t2;
	private JPasswordField t3;
	private JPasswordField t4;

	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ones1 window = new Ones1();
					window.frame1.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}); 
	}

	
	
	
       
	public Ones1()
	{
		
		frame1 = new JFrame();
		frame1.setBounds(0, 0,1370, 730);
		frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame1.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 1354, 692);
		frame1.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(214, 65, 925, 584);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("Enter Username");
		lblNewLabel_2.setForeground(new Color(204, 0, 153));
		lblNewLabel_2.setBackground(new Color(102, 204, 204));
		lblNewLabel_2.setFont(new Font("Berlin Sans FB", Font.PLAIN, 30));
		lblNewLabel_2.setBounds(91, 196, 203, 34);
		panel_1.add(lblNewLabel_2);
		
		t1 = new JTextField();
		t1.setFont(new Font("Berlin Sans FB", Font.PLAIN, 25));
		t1.setBounds(91, 241, 293, 34);
		panel_1.add(t1);
		t1.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Enter Email Address");
		lblNewLabel_3.setForeground(new Color(204, 0, 153));
		lblNewLabel_3.setFont(new Font("Berlin Sans FB", Font.PLAIN, 30));
		lblNewLabel_3.setBounds(569, 198, 293, 30);
		panel_1.add(lblNewLabel_3);
		
		t2 = new JTextField();
		t2.setFont(new Font("Berlin Sans FB", Font.PLAIN, 25));
		t2.setBounds(569, 241, 293, 34);
		panel_1.add(t2);
		t2.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Enter Password");
		lblNewLabel_4.setForeground(new Color(204, 0, 153));
		lblNewLabel_4.setFont(new Font("Berlin Sans FB", Font.PLAIN, 30));
		lblNewLabel_4.setBounds(91, 320, 203, 34);
		panel_1.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Re-enter Password");
		lblNewLabel_5.setForeground(new Color(204, 0, 153));
		lblNewLabel_5.setFont(new Font("Berlin Sans FB", Font.PLAIN, 30));
		lblNewLabel_5.setBounds(569, 320, 268, 34);
		panel_1.add(lblNewLabel_5);
		
		JButton b = new JButton("Create Account");
		b.setForeground(new Color(102, 102, 0));
		b.setBackground(new Color(250, 235, 215));
		b.setFont(new Font("Narkisim", Font.BOLD, 23));
		b.setIcon(new ImageIcon(Ones1.class.getResource("/image/check-user-icon (1).png")));
		b.setBounds(368, 509, 227, 49);
		panel_1.add(b);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(Ones1.class.getResource("/image/Male-user-add-icon.png")));
		lblNewLabel_1.setBounds(419, 11, 116, 102);
		panel_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(Ones1.class.getResource("/image/75Z2XU.jpg")));
		lblNewLabel.setBounds(0, 0, 1416, 768);
		panel.add(lblNewLabel);
		
		ButtonGroup g = new ButtonGroup();
		
		JLabel l5 = new JLabel("");
		l5.setForeground(new Color(100, 149, 237));
		l5.setFont(new Font("Berlin Sans FB", Font.PLAIN, 30));
		l5.setBounds(244, 448, 457, 41);
		panel_1.add(l5);
		
		t3 = new JPasswordField();
		t3.setBounds(91, 386, 293, 34);
		panel_1.add(t3);
		
		t4 = new JPasswordField();
		t4.setBounds(569, 386, 283, 34);
		panel_1.add(t4);
		
		JLabel lblLoginAsStudent = new JLabel("Log-in as Student");
		lblLoginAsStudent.setForeground(new Color(204, 0, 102));
		lblLoginAsStudent.setFont(new Font("Berlin Sans FB", Font.PLAIN, 30));
		lblLoginAsStudent.setBackground(new Color(102, 204, 204));
		lblLoginAsStudent.setBounds(354, 124, 241, 34);
		panel_1.add(lblLoginAsStudent);
	

		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent q) {	 
				String s1=t1.getText();
				String s2=t2.getText();
				char[] s = t3.getPassword();
				char[] s6 = t4.getPassword();
				String s3=String.valueOf(s);
				String s4=String.valueOf(s6);
				
				
				try {
					
					if (!s3.equals(s4))
					{
						l5.setText("Password does not match.Re-enter");
						
					}
					else
					{
						
					
					String url="jdbc:oracle:thin:@localhost:1521:xe";
					String username="username";
					String password="password";
					String role="student";
					String s5="smuser.nextval";
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con = DriverManager.getConnection(url,username,password);
					
				
					String query="insert into muser values(smuser.nextval,'"+s1+"','"+s3+"','"+s2+"','"+role+"')";

					
					PreparedStatement sta=con.prepareStatement(query);
					
					l5.setText("Account Created");
					int count=sta.executeUpdate();
					sta.close();
					con.close();
					
					
					OneS o=new OneS();
					o.frame.setVisible(true);
					frame1.dispose();
					}
					}
				
				 catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
		}
			
		});

	
		
		
	}
}


