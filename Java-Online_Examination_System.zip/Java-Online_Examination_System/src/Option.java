import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.Font;
import java.awt.Color;

public class Option {

	JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Option window = new Option();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Option() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(0, 0,1362 , 730);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton modanswer = new JButton("Modify Answer");
	
		modanswer.setFont(new Font("Arial Unicode MS", Font.PLAIN, 20));
		modanswer.setIcon(new ImageIcon(Option.class.getResource("/image/arrow-right-icon.png")));
		
		JLabel lblNewLabel_13 = new JLabel("and set Answer for each Question.");
		lblNewLabel_13.setForeground(new Color(0, 0, 0));
		lblNewLabel_13.setFont(new Font("Gill Sans MT", Font.BOLD, 16));
		lblNewLabel_13.setBounds(996, 528, 282, 22);
		frame.getContentPane().add(lblNewLabel_13);
		
		JLabel lblNewLabel_12 = new JLabel("Make sure you have only 4 Options in each Question\r\n");
		lblNewLabel_12.setForeground(new Color(0, 0, 0));
		lblNewLabel_12.setFont(new Font("Gill Sans MT", Font.BOLD, 16));
		lblNewLabel_12.setBounds(940, 505, 396, 22);
		frame.getContentPane().add(lblNewLabel_12);
		JLabel lblNewLabel_11 = new JLabel("Select Question and");
		lblNewLabel_11.setForeground(new Color(102, 0, 0));
		lblNewLabel_11.setFont(new Font("Baskerville Old Face", Font.BOLD, 24));
		lblNewLabel_11.setBounds(1092, 580, 210, 22);
		frame.getContentPane().add(lblNewLabel_11);
		
		JLabel lblNewLabel_10 = new JLabel("Select Option and");
		lblNewLabel_10.setForeground(new Color(102, 0, 0));
		lblNewLabel_10.setFont(new Font("Baskerville Old Face", Font.BOLD, 24));
		lblNewLabel_10.setBounds(822, 580, 210, 22);
		frame.getContentPane().add(lblNewLabel_10);
		
		JLabel lblNewLabel_9 = new JLabel("Select Option and");
		lblNewLabel_9.setForeground(new Color(102, 0, 0));
		lblNewLabel_9.setFont(new Font("Baskerville Old Face", Font.BOLD, 24));
		lblNewLabel_9.setBounds(576, 580, 210, 22);
		frame.getContentPane().add(lblNewLabel_9);
		
		JLabel lblNewLabel_8 = new JLabel("Select Option and");
		lblNewLabel_8.setForeground(new Color(102, 0, 0));
		lblNewLabel_8.setFont(new Font("Baskerville Old Face", Font.BOLD, 24));
		lblNewLabel_8.setBounds(319, 580, 210, 22);
		frame.getContentPane().add(lblNewLabel_8);
		
		JLabel lblNewLabel_7 = new JLabel("Select Question and");
		lblNewLabel_7.setForeground(new Color(102, 0, 0));
		lblNewLabel_7.setFont(new Font("Baskerville Old Face", Font.BOLD, 24));
		lblNewLabel_7.setBounds(48, 577, 210, 22);
		frame.getContentPane().add(lblNewLabel_7);
		
		JLabel lblNewLabel_6 = new JLabel("Select Question and");
		lblNewLabel_6.setForeground(new Color(0, 0, 153));
		lblNewLabel_6.setBackground(new Color(204, 255, 255));
		lblNewLabel_6.setFont(new Font("Baskerville Old Face", Font.BOLD, 22));
		lblNewLabel_6.setBounds(44, 507, 214, 33);
		frame.getContentPane().add(lblNewLabel_6);
		
		JLabel lblNewLabel_5 = new JLabel("Questions");
		lblNewLabel_5.setForeground(new Color(204, 0, 153));
		lblNewLabel_5.setFont(new Font("Andalus", Font.BOLD, 26));
		lblNewLabel_5.setBounds(262, 160, 160, 23);
		frame.getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_4 = new JLabel("Options");
		lblNewLabel_4.setForeground(new Color(204, 0, 153));
		lblNewLabel_4.setFont(new Font("Andalus", Font.BOLD, 26));
		lblNewLabel_4.setBounds(1022, 160, 141, 23);
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_3 = new JLabel("Select Question and");
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setFont(new Font("Baskerville Old Face", Font.BOLD, 22));
		lblNewLabel_3.setBounds(1075, 47, 203, 25);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_2 = new JLabel("Select Exam and");
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("Baskerville Old Face", Font.BOLD, 22));
		lblNewLabel_2.setBackground(Color.WHITE);
		lblNewLabel_2.setBounds(837, 47, 172, 34);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_1 = new JLabel("Select Exam");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 22));
		lblNewLabel_1.setBounds(10, 92, 160, 33);
		frame.getContentPane().add(lblNewLabel_1);
		
		JButton showans = new JButton("Show Answer");
		showans.setFont(new Font("Arial Unicode MS", Font.PLAIN, 20));
		showans.setIcon(new ImageIcon(Option.class.getResource("/image/Search-icon (2).png")));
		showans.setBounds(251, 505, 200, 33);
		frame.getContentPane().add(showans);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(505, 505, 414, 33);
		frame.getContentPane().add(scrollPane_2);
		
		JList list3 = new JList();
		list3.setBackground(new Color(220, 220, 220));
		list3.setFont(new Font("Tahoma", Font.BOLD, 17));
		scrollPane_2.setViewportView(list3);
		modanswer.setBounds(1102, 619, 199, 35);
		frame.getContentPane().add(modanswer);
		
		JButton showo = new JButton("Show Options");
		showo.setFont(new Font("Arial Unicode MS", Font.PLAIN, 20));
		showo.setIcon(new ImageIcon(Option.class.getResource("/image/Search-icon (2).png")));
		
		showo.setBounds(1075, 92, 220, 33);
		frame.getContentPane().add(showo);
		
		JButton setanswer = new JButton("Set Answer");
		setanswer.setIcon(new ImageIcon(Option.class.getResource("/image/Button-Fast-Forward-icon.png")));
		setanswer.setFont(new Font("Arial Unicode MS", Font.PLAIN, 20));
		
		setanswer.setBounds(837, 619, 180, 35);
		frame.getContentPane().add(setanswer);
		
		JButton del = new JButton("Delete Option");
		del.setFont(new Font("Arial Unicode MS", Font.PLAIN, 20));
		del.setIcon(new ImageIcon(Option.class.getResource("/image/Button-Close-icon (1).png")));
		del.setBounds(576, 619, 190, 35);
		frame.getContentPane().add(del);
		
		
		JButton change = new JButton("Modify Option");
		change.setIcon(new ImageIcon(Option.class.getResource("/image/arrow-right-icon.png")));
		change.setFont(new Font("Arial Unicode MS", Font.PLAIN, 20));
		
		change.setBounds(329, 619, 190, 35);
		frame.getContentPane().add(change);
		
		JButton add = new JButton("Add Option");
		add.setIcon(new ImageIcon(Option.class.getResource("/image/Button-Add-icon (1).png")));
		add.setFont(new Font("Arial Unicode MS", Font.PLAIN, 20));
	
	add.setBounds(68, 619, 180, 35);
		frame.getContentPane().add(add);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(860, 205, 456, 260);
		frame.getContentPane().add(scrollPane_1);
		
		JList list2 = new JList();
		list2.setBackground(new Color(220, 220, 220));
		list2.setFont(new Font("Tahoma", Font.BOLD, 17));
		scrollPane_1.setViewportView(list2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(68, 205, 657, 260);
		frame.getContentPane().add(scrollPane);
		
		JList list1 = new JList();
		list1.setBackground(new Color(220, 220, 220));
		list1.setForeground(new Color(0, 0, 0));
		list1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				 try
				 {String a = (String) list1.getSelectedValue();
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con2=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
					Statement st2=con2.createStatement();
					String sql = "select actualoptions from moption where questionid in(select questionid from mquestion where actualquestion='"+a+"')";
					ResultSet r=st2.executeQuery(sql);
					DefaultListModel dlm=new DefaultListModel();
				    while (r.next()){
					dlm.addElement(r.getString(1));
				    }
				    st2.close();
					   con2.close();
					   list2.setModel(dlm);
				    }
					catch(Exception ae)
					{
						ae.printStackTrace();
					}
				  try {
						 String a = (String) list1.getSelectedValue();

						Class.forName("oracle.jdbc.driver.OracleDriver");
						Connection con2=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
						Statement st2=con2.createStatement();
						String sql = "select answer from mquestion  where  actualquestion='"+a+"'";
						ResultSet r=st2.executeQuery(sql);
						DefaultListModel dlm=new DefaultListModel();
					    while (r.next()){
						dlm.addElement(r.getString(1));
					    }
					    st2.close();
						   con2.close();
						   list3.setModel(dlm);
					    }
						catch(Exception eh)
						{
							eh.printStackTrace();
						}
			}
		});
		list1.setFont(new Font("Tahoma", Font.BOLD, 17));
		scrollPane.setViewportView(list1);
		
		JButton showq = new JButton("Show Questions");
		showq.setIcon(new ImageIcon(Option.class.getResource("/image/Search-icon (2).png")));
		showq.setFont(new Font("Arial Unicode MS", Font.PLAIN, 20));
	
		showq.setBounds(812, 92, 220, 33);
		frame.getContentPane().add(showq);
		
		JComboBox c = new JComboBox();
		c.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				
				try {
					System.out.println("HAN");
					 String a = (String) c.getItemAt(c.getSelectedIndex());
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con2=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
					Statement st2=con2.createStatement();
					String sql = "select actualquestion from mquestion q,mexam e where q.examid=e.examid and examname='"+a+"'";
					ResultSet r=st2.executeQuery(sql);
					DefaultListModel dlm=new DefaultListModel();
				    while (r.next()){
					dlm.addElement(r.getString(1));
				    }
				    st2.close();
					   con2.close();
					   list1.setModel(dlm);
				    }
					catch(Exception ek)
					{
						ek.printStackTrace();
					}
			}
		});
		c.setFont(new Font("Tahoma", Font.BOLD, 15));
		c.setBounds(180, 92, 607, 33);
		frame.getContentPane().add(c);
		
		JComboBox c1 = new JComboBox();
		
		frame.getContentPane().add(c1);
		
		JButton main = new JButton("Go Back To Main Page");

		main.setIcon(new ImageIcon(Option.class.getResource("/image/go-back-icon (1).png")));
		main.setFont(new Font("Tempus Sans ITC", Font.BOLD, 19));
		main.setBounds(46, 25, 270, 30);
		frame.getContentPane().add(main);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(0, 0, 1366, 724);
		lblNewLabel.setIcon(new ImageIcon(Option.class.getResource("/image/imgonline-com-ua-resize-CoDsdEXtEM0mx.jpg")));
		frame.getContentPane().add(lblNewLabel);
		
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st=con.createStatement();
			String sql = "select examname from mexam";
			ResultSet r=st.executeQuery(sql);
			
		    while (r.next()){
			c.addItem(r.getString(1));
		    }
		   st.close();
		   con.close();
		    }
			catch(Exception e)
			{
				e.printStackTrace();
			}
		try {
			 String a = (String) c.getItemAt(c.getSelectedIndex());
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con2=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st2=con2.createStatement();
			String sql = "select actualquestion from mquestion q,mexam e where q.examid=e.examid and examname='"+a+"'";
			ResultSet r=st2.executeQuery(sql);
			DefaultListModel dlm=new DefaultListModel();
		    while (r.next()){
			dlm.addElement(r.getString(1));
		    }
		    st2.close();
			   con2.close();
			   list1.setModel(dlm);
		    }
			catch(Exception e)
			{
				e.printStackTrace();
			}
		
		
		
		
		showq.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					
					 String a = (String) c.getItemAt(c.getSelectedIndex());
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con2=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
					Statement st2=con2.createStatement();
					String sql = "select actualquestion from mquestion q,mexam e where q.examid=e.examid and examname='"+a+"'";
					ResultSet r=st2.executeQuery(sql);
					DefaultListModel dlm=new DefaultListModel();
				    while (r.next()){
					dlm.addElement(r.getString(1));
				    }
				    st2.close();
					   con2.close();
					   list1.setModel(dlm);
				    }
					catch(Exception e)
					{
						e.printStackTrace();
					}
			}
		});
		
		
		showo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 try
				 {String a = (String) list1.getSelectedValue();
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con2=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
					Statement st2=con2.createStatement();
					String sql = "select actualoptions from moption where questionid in(select questionid from mquestion where actualquestion='"+a+"')";
					ResultSet r=st2.executeQuery(sql);
					DefaultListModel dlm=new DefaultListModel();
				    while (r.next()){
					dlm.addElement(r.getString(1));
				    }
				    st2.close();
					   con2.close();
					   list2.setModel(dlm);
				    }
					catch(Exception ae)
					{
						ae.printStackTrace();
					}
			}
		});
		
		
		add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s=(String) list1.getSelectedValue();
				String a="Please Select a Question!";
				if (s==null)
				  {
			  JOptionPane.showMessageDialog(frame,a, a, JOptionPane.ERROR_MESSAGE);
				  }
		  else {
			
			
						String m=JOptionPane.showInputDialog(frame, "Enter Option to be added in '"+s+"'");  
						if(m==null)
						{
							return ;
						}
						else
						{
					     try
					     {
					     String url="jdbc:oracle:thin:@localhost:1521:xe";
							String username="username";
							String password="password";
							Class.forName("oracle.jdbc.driver.OracleDriver");
							Connection con10 = DriverManager.getConnection(url,username,password);

							String query="insert into moption values(smoptionsid.nextval,'"+m+"',(select questionid from mquestion where actualquestion='"+s+"'))";   
							PreparedStatement st10=con10.prepareStatement(query);
							int count=st10.executeUpdate();
							st10.close();
							   con10.close();
						}
					     catch(Exception ea)
					     {
					    	 ea.printStackTrace();
					     }
					     try
						 {
							String aa = (String) list1.getSelectedValue();
							Class.forName("oracle.jdbc.driver.OracleDriver");
							Connection con2=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
							Statement st2=con2.createStatement();
							String sql = "select actualoptions from moption where questionid in(select questionid from mquestion where actualquestion='"+aa+"')";
							ResultSet r=st2.executeQuery(sql);
							DefaultListModel dlm=new DefaultListModel();
						    while (r.next()){
							dlm.addElement(r.getString(1));
						    }
						    list2.setModel(dlm);
						    st2.close();
							   con2.close();
							 
						    }
							catch(Exception ae)
							{
								ae.printStackTrace();
							}
		  }
		  }
			}
		});
		
		
		
		change.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String s=(String) list2.getSelectedValue();
				String z=(String) list1.getSelectedValue();
				String a="Please Select a Option!";
				if (s==null)
				  {
			  JOptionPane.showMessageDialog(frame,a, a, JOptionPane.ERROR_MESSAGE);
				  }
		  else {
			
		
						String m=JOptionPane.showInputDialog(frame, "Change Option '"+s+"'");  
						if(m==null)
						{
							return ;
						}
						else
						{
					     try
					     {
					     String url="jdbc:oracle:thin:@localhost:1521:xe";
							String username="username";
							String password="password";
							Class.forName("oracle.jdbc.driver.OracleDriver");
							Connection con10 = DriverManager.getConnection(url,username,password);

							String query="update moption set actualoptions='"+m+"' where actualoptions='"+s+"'";   
							String q="update mquestion set answer=null where actualquestion='"+z+"'"; 
							
							PreparedStatement st10=con10.prepareStatement(query);
							PreparedStatement st11=con10.prepareStatement(q);

							int count=st10.executeUpdate();
							int c=st11.executeUpdate();
							st11.close();
							
							st11.close();
							
							st10.close();
							   con10.close();
						}
					     catch(Exception ea)
					     {
					    	 ea.printStackTrace();
					     }
					     
							try
							 {
								String as = (String) list1.getSelectedValue();
								Class.forName("oracle.jdbc.driver.OracleDriver");
								Connection con2=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
								Statement st2=con2.createStatement();
								String sql = "select actualoptions from moption where questionid in(select questionid from mquestion where actualquestion='"+as+"')";
								ResultSet r=st2.executeQuery(sql);
								DefaultListModel dlm=new DefaultListModel();
							    while (r.next()){
								dlm.addElement(r.getString(1));
							    }
							    list2.setModel(dlm);
							    st2.close();
								   con2.close();
								 
							    }
								catch(Exception ae)
								{
									ae.printStackTrace();
								}
							  
							  try {
									Class.forName("oracle.jdbc.driver.OracleDriver");
									Connection con2=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
									Statement st2=con2.createStatement();
									String sql = "select answer from mquestion  where  actualquestion='"+s+"'";
									ResultSet r=st2.executeQuery(sql);
									DefaultListModel dlm=new DefaultListModel();
								    while (r.next()){
									dlm.addElement(r.getString(1));
								    }
								    st2.close();
									   con2.close();
									   list3.setModel(dlm);
								    }
									catch(Exception re)
									{
										re.printStackTrace();
									}
		  }
		  }
			}
		});
		
		
		
		
		
		
		del.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String s=(String) list2.getSelectedValue();
				String h=(String) list1.getSelectedValue();
				String z=(String) list1.getSelectedValue();

				String a="Please Select a Option!";
				if (s==null)
				  {
			  JOptionPane.showMessageDialog(frame,a, a, JOptionPane.ERROR_MESSAGE);
				  }
		  else {
				int result = JOptionPane.showConfirmDialog(frame,"OPTION '"+s+"' will be deleted from Question'"+h+"'", "Delete Option",
			               JOptionPane.YES_NO_OPTION,
			               JOptionPane.ERROR_MESSAGE);
				
				if(result == JOptionPane.YES_OPTION){
			
						
					     try
					     {
					     String url="jdbc:oracle:thin:@localhost:1521:xe";
							String username="username";
							String password="password";
							Class.forName("oracle.jdbc.driver.OracleDriver");
							Connection con10 = DriverManager.getConnection(url,username,password);

							String query="delete moption where actualoptions='"+s+"'";   
							String q="update mquestion set answer=null where actualquestion='"+z+"'"; 
							
							PreparedStatement st10=con10.prepareStatement(query);
							PreparedStatement st11=con10.prepareStatement(q);

							
							int count=st10.executeUpdate();
							int c=st11.executeUpdate();
							st11.close();

							st10.close();
							   con10.close();
						}
					     catch(Exception ea)
					     {
					    	 ea.printStackTrace();
					     } 
					     }
				else
				{
					return ;
				}
				try
				 {
					String as = (String) list1.getSelectedValue();
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con2=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
					Statement st2=con2.createStatement();
					String sql = "select actualoptions from moption where questionid in(select questionid from mquestion where actualquestion='"+as+"')";
					ResultSet r=st2.executeQuery(sql);
					DefaultListModel dlm=new DefaultListModel();
				    while (r.next()){
					dlm.addElement(r.getString(1));
				    }
				    list2.setModel(dlm);
				    st2.close();
					   con2.close();
					 
				    }
					catch(Exception ae)
					{
						ae.printStackTrace();
					}
		  
				  try {
						Class.forName("oracle.jdbc.driver.OracleDriver");
						Connection con2=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
						Statement st2=con2.createStatement();
						String sql = "select answer from mquestion  where  actualquestion='"+s+"'";
						ResultSet r=st2.executeQuery(sql);
						DefaultListModel dlm=new DefaultListModel();
					    while (r.next()){
						dlm.addElement(r.getString(1));
					    }
					    st2.close();
						   con2.close();
						   list3.setModel(dlm);
					    }
						catch(Exception re)
						{
							re.printStackTrace();
						}
		  }
				
				}
			
		});
		
		
		
		
		
		
		setanswer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String v=(String) list2.getSelectedValue();
				String q=(String) list1.getSelectedValue();
				

				String a="Please Select a Option!";
				if (v==null)
				  {
			  JOptionPane.showMessageDialog(frame,a,  "Select a Option", JOptionPane.ERROR_MESSAGE);
				  }
		  else {
				
				
				
				
				 try
			     {
			     String url="jdbc:oracle:thin:@localhost:1521:xe";
					String username="username";
					String password="password";
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con10 = DriverManager.getConnection(url,username,password);

					String query="update mquestion set answer='"+v+"' where actualquestion='"+q+"'";   
					PreparedStatement st10=con10.prepareStatement(query);
					int count=st10.executeUpdate();
					st10.close();
					   con10.close();
				}
			     catch(Exception ea)
			     {
			    	 ea.printStackTrace();
			     }
				
				
				c1.removeAllItems();
				String s=(String) list1.getSelectedValue();
				
				  try {
						Class.forName("oracle.jdbc.driver.OracleDriver");
						Connection con2=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
						Statement st2=con2.createStatement();
						String sql = "select answer from mquestion  where  actualquestion='"+s+"'";
						ResultSet r=st2.executeQuery(sql);
						DefaultListModel dlm=new DefaultListModel();
					    while (r.next()){
						dlm.addElement(r.getString(1));
					    }
					    st2.close();
						   con2.close();
						   list3.setModel(dlm);
					    }
						catch(Exception es)
						{
							es.printStackTrace();
						}
		  }
			}
		});
		
		
		modanswer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String v=(String) list1.getSelectedValue();

				String a="Please Select a Option!";
				if (v==null)
				  {
			  JOptionPane.showMessageDialog(frame,a, "Select a Option", JOptionPane.ERROR_MESSAGE);
				  }
		  else {
				
				try {
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
					Statement st=con.createStatement();
					String sql = "select actualoptions from moption where questionid in(select questionid from mquestion where actualquestion='"+v+"')";
					ResultSet r=st.executeQuery(sql);
					
				    while (r.next()){
					c1.addItem(r.getString(1));
				    }
					JOptionPane.showMessageDialog(frame, c1, "Select new Answer", JOptionPane.INFORMATION_MESSAGE);

				   st.close();
				   con.close();
				    }
					catch(Exception ef)
					{
						ef.printStackTrace();
					}
				
				String k=(String) c1.getItemAt(c1.getSelectedIndex());
				
				 try
			     {
			     String url="jdbc:oracle:thin:@localhost:1521:xe";
					String username="username";
					String password="password";
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con10 = DriverManager.getConnection(url,username,password);

					String query="update mquestion set answer='"+k+"' where actualquestion='"+v+"'";   
					PreparedStatement st10=con10.prepareStatement(query);
					int count=st10.executeUpdate();
					st10.close();
					   con10.close();
				}
			     catch(Exception ea)
			     {
			    	 ea.printStackTrace();
			     }
				
				
				c1.removeAllItems();
				String s=(String) list1.getSelectedValue();
				
				  
				  try {
						Class.forName("oracle.jdbc.driver.OracleDriver");
						Connection con2=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
						Statement st2=con2.createStatement();
						String sql = "select answer from mquestion  where  actualquestion='"+s+"'";
						ResultSet r=st2.executeQuery(sql);
						DefaultListModel dlm=new DefaultListModel();
					    while (r.next()){
						dlm.addElement(r.getString(1));
					    }
					    st2.close();
						   con2.close();
						   list3.setModel(dlm);
					    }
						catch(Exception re)
						{
							re.printStackTrace();
						}

		  }
			}
		});

		showans.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String s=(String) list1.getSelectedValue();
				String a="Please Select a Question!";
				if (s==null)
				  {
			  JOptionPane.showMessageDialog(frame,a, a, JOptionPane.ERROR_MESSAGE);
				  }
		  else {
			  
			  try {
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con2=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
					Statement st2=con2.createStatement();
					String sql = "select answer from mquestion  where  actualquestion='"+s+"'";
					ResultSet r=st2.executeQuery(sql);
					DefaultListModel dlm=new DefaultListModel();
				    while (r.next()){
					dlm.addElement(r.getString(1));
				    }
				    st2.close();
					   con2.close();
					   list3.setModel(dlm);
				    }
					catch(Exception e)
					{
						e.printStackTrace();
					}
			  
		  }
			}
		});
		
		
	
		
		
		
		
		main.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				frame.dispose();
				Ones2 i=new Ones2();
				i.frame1.setVisible(true);
			}
		});
		
		
		
	}
}
