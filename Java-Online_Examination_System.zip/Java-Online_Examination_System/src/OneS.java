import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.JCheckBox;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.Toolkit;
import java.awt.ComponentOrientation;
import java.awt.Cursor;
import javax.swing.JRadioButton;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.UIManager;

public class OneS {

	 JFrame frame;
	 JPanel panel; 
	 JLabel l,lblNewLabel,lblNewLabel_1,lblNewLabel_2,lblNewLabel_3,lblNewLabel_4,lblNewLabel_5,lblNewLabel_6, lblNewLabel_7, lblNewLabel_8,l4,label, lblNewLabel_9 ;
	 JButton b,b1;
	 JRadioButton r1,r2;
	 JTextField u;
	 
	  JPasswordField passwordField;


	 public static void main(String[] args) {
			
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						OneS window = new OneS();
						window.frame.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}); 
		}

	

	
	
	public OneS() {   //Constructor
		
	String ha="KKKO";
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(85, 73, 1177, 573);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		 l = new JLabel("Eduizz");
		l.setForeground(new Color(51, 102, 204));
		l.setFont(new Font("Comic Sans MS", Font.BOLD, 50));
		l.setBounds(95, 271, 224, 79);
		panel.add(l);
		
		 lblNewLabel = new JLabel("New label");
		lblNewLabel.setBackground(new Color(230, 230, 250));
		lblNewLabel.setIcon(new ImageIcon(OneS.class.getResource("/image/User.png")));
		lblNewLabel.setBounds(85, 35, 224, 225);
		panel.add(lblNewLabel);
		
		 lblNewLabel_1 = new JLabel("Educational Quizz!!!");
		lblNewLabel_1.setForeground(new Color(102, 153, 0));
		lblNewLabel_1.setFont(new Font("Narkisim", Font.BOLD, 30));
		lblNewLabel_1.setBounds(65, 356, 291, 44);
		panel.add(lblNewLabel_1);
		
		 lblNewLabel_2 = new JLabel("Log In");
		lblNewLabel_2.setForeground(new Color(153, 0, 204));
		lblNewLabel_2.setBackground(new Color(255, 255, 255));
		lblNewLabel_2.setFont(new Font("Narkisim", Font.PLAIN, 50));
		lblNewLabel_2.setBounds(748, 11, 187, 79);
		panel.add(lblNewLabel_2);
		
		 lblNewLabel_3 = new JLabel("Enter Username");
		lblNewLabel_3.setForeground(new Color(204, 51, 153));
		lblNewLabel_3.setFont(new Font("Bookman Old Style", Font.BOLD, 30));
		lblNewLabel_3.setBounds(424, 115, 278, 51);
		panel.add(lblNewLabel_3);
		
		 lblNewLabel_4 = new JLabel("Enter Password");
		lblNewLabel_4.setForeground(new Color(204, 51, 153));
		lblNewLabel_4.setFont(new Font("Bookman Old Style", Font.BOLD, 30));
		lblNewLabel_4.setBounds(424, 210, 252, 44);
		panel.add(lblNewLabel_4);
		
		 lblNewLabel_5 = new JLabel("Log in as");
		lblNewLabel_5.setForeground(new Color(204, 51, 153));
		lblNewLabel_5.setFont(new Font("Bookman Old Style", Font.BOLD, 32));
		lblNewLabel_5.setBounds(475, 290, 213, 53);
		panel.add(lblNewLabel_5);
		
		 b = new JButton("Click to Confirm");
		b.setIcon(new ImageIcon(OneS.class.getResource("/image/Button-Fast-Forward-icon.png")));
		b.setForeground(new Color(102, 153, 204));
		b.setBackground(new Color(245, 245, 220));
		b.setBorder(UIManager.getBorder("Button.border"));
		b.setFont(new Font("Corbel", Font.BOLD, 23));
		b.setBounds(634, 378, 240, 51);
		panel.add(b);
		
		 r1 = new JRadioButton("Student");
		r1.setForeground(new Color(204, 51, 153));
		r1.setFont(new Font("Century Schoolbook", Font.BOLD, 30));
		r1.setBounds(694, 298, 166, 37);
		panel.add(r1);
		
		 r2 = new JRadioButton("Admin");
		r2.setForeground(new Color(204, 51, 153));
		r2.setFont(new Font("Century Schoolbook", Font.BOLD, 30));
		r2.setBounds(896, 298, 141, 37);
		panel.add(r2);
		
		 lblNewLabel_6 = new JLabel("If you do not have an account,");
		lblNewLabel_6.setBackground(new Color(204, 51, 153));
		lblNewLabel_6.setForeground(new Color(204, 51, 153));
		lblNewLabel_6.setFont(new Font("Bookman Old Style", Font.BOLD, 30));
		lblNewLabel_6.setBounds(399, 495, 503, 51);
		panel.add(lblNewLabel_6);
		
		 b1 = new JButton("Sign Up");
		b1.setIcon(new ImageIcon(OneS.class.getResource("/image/user-edit-icon.png")));
		b1.setBackground(new Color(245, 245, 220));
		b1.setForeground(new Color(51, 153, 204));
		b1.setFont(new Font("Corbel", Font.PLAIN, 29));
		b1.setBounds(912, 502, 177, 44);
		panel.add(b1);
		
		 u = new JTextField();
		u.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 23));
		u.setBackground(new Color(230, 230, 250));
		u.setBounds(695, 124, 463, 37);
		panel.add(u);
		u.setColumns(10);
		
		 lblNewLabel_7 = new JLabel("New label");
		lblNewLabel_7.setIcon(new ImageIcon(OneS.class.getResource("/image/images (9).jpg")));
		lblNewLabel_7.setBounds(65, 388, 278, 158);
		panel.add(lblNewLabel_7);
		
		 lblNewLabel_8 = new JLabel("");
		lblNewLabel_8.setIcon(new ImageIcon(OneS.class.getResource("/image/Unlock-icon.png")));
		lblNewLabel_8.setBounds(634, 11, 81, 76);
		panel.add(lblNewLabel_8);
		frame.setBounds(0, 0,1370, 730);
		
		ButtonGroup bg=new ButtonGroup();
		bg.add(r1);
		bg.add(r2);
		
		l4 = new JLabel("");
		l4.setForeground(new Color(204, 0, 0));
		l4.setFont(new Font("Bookman Old Style", Font.BOLD, 24));
		l4.setBounds(424, 440, 807, 44);
		panel.add(l4);
		
		passwordField = new JPasswordField();
		passwordField.setBackground(new Color(230, 230, 250));
		passwordField.setBounds(695, 210, 468, 37);
		panel.add(passwordField);
		
		 label = new JLabel("New label");
		label.setBounds(-26, 0, 32, -4);
		frame.getContentPane().add(label);
		
		 lblNewLabel_9 = new JLabel("");
		lblNewLabel_9.setIcon(new ImageIcon(OneS.class.getResource("/image/75Z2XU.jpg")));
		lblNewLabel_9.setBounds(0, 0, 1354, 692);
		frame.getContentPane().add(lblNewLabel_9);
		
		

		
		
		
		
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent p) {
			 Ones1 obj = new Ones1();
			  obj.frame1.setVisible(true);
			 frame.dispose();
		    
			}
			
		});
		
		
		
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent a) {
				String s=u.getText();
				
				
				
				
				char[] s6 = passwordField.getPassword();
				
				String s1=String.valueOf(s6);
				String role;
				role="student";
				
				
				
	
				
				
				try {
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
					Statement st=con.createStatement();
					ResultSet rs=st.executeQuery("select * from muser");    //QUERY WHICH IS TO BE EXECUTED
					for(int i=1;rs.next();i++)  
					{
						String user=rs.getString(2);
						String pass=rs.getString(3);
						String roled =rs.getString(5);
						
					if (user.equals(s)  && pass.equals(s1))
					{
						if(r1.isSelected())
						{
							role="student";
							if(roled.equals(role))
							{
								
								try {
									
									Class.forName("oracle.jdbc.driver.OracleDriver");
									Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
									Statement st1=con1.createStatement();
									String sql = "select userid from muser where username='"+user+"'";
									ResultSet r=st1.executeQuery(sql);
								    while (r.next()){
								    	String aa=r.getString(1);
								    	int studid = Integer.parseInt(aa);
								    	frame.dispose();
								    	Student sa= new Student(studid);
										sa.frame.setVisible(true);
								    }
								    
								st1.close();
							    con1.close();
								}	
							    catch(Exception e)
									{
										e.printStackTrace();
									}

								
								
								
								
						
				
							}
						
						
						}
						else if (r2.isSelected())
						{
							role="admin";
							
							if(roled.equals(role))
							{
								l4.setText("LOGIN SUCCESSFUL");
								frame.dispose();
								Ones2 obj = new Ones2();
								obj.frame1.setVisible(true);
							
							}
						}
						else
							break;					    	
					}
					else {
						
						l4.setText("Please enter valid username or password or select a role");
					}

					}
				} catch (Exception e) {
					
					e.printStackTrace();
				}
			}

		});

	

	}
}