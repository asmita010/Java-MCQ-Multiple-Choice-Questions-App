import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Student {

	 JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Student window = new Student(0);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Student(int st) {
		int studid=st;
		initialize(studid);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(int st) {
		int studid=st;
		frame = new JFrame();
		frame.setBounds(0, 0,1362 , 730);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 36, 653, 656);
		frame.getContentPane().add(panel);
		panel.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(Student.class.getResource("/image/A.jpg")));
		panel.add(lblNewLabel, BorderLayout.CENTER);
		
		JLabel lblNewLabel_1 = new JLabel("Select Exam that you want to give");
		lblNewLabel_1.setForeground(new Color(204, 0, 102));
		lblNewLabel_1.setFont(new Font("Gill Sans Ultra Bold", Font.PLAIN, 23));
		lblNewLabel_1.setBounds(723, 67, 544, 40);
		frame.getContentPane().add(lblNewLabel_1);
		
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(723, 139, 544, 333);
		frame.getContentPane().add(scrollPane);
		
		JList list = new JList();
		list.setFont(new Font("Tahoma", Font.BOLD, 18));
		scrollPane.setViewportView(list);
		
		JButton btnNewButton = new JButton("Start Exam");
		
		btnNewButton.setForeground(new Color(51, 51, 153));
		btnNewButton.setFont(new Font("Gill Sans Ultra Bold", Font.BOLD, 18));
		btnNewButton.setBounds(893, 581, 203, 40);
		frame.getContentPane().add(btnNewButton);
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st1=con1.createStatement();
			String sql = "select examname from mexam";
			ResultSet r=st1.executeQuery(sql);
			DefaultListModel dlm=new DefaultListModel();
		    while (r.next()){
			dlm.addElement(r.getString(1));
		    }
		    list.setModel(dlm);
		    
		st1.close();
	    con1.close();
		}	
	    catch(Exception e)
			{
				e.printStackTrace();
			}

		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String sa=(String) list.getSelectedValue();
				
				try {
					
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
					Statement st1=con1.createStatement();
					String sql = "select time from mexam where examname='"+sa+"'";
					ResultSet r=st1.executeQuery(sql);

					while (r.next()){
						String ar=r.getString(1);
						int time = Integer.parseInt(ar);
						frame.dispose();
						StudentQuestion saa=new StudentQuestion(studid,sa,time);
						saa.frame.setVisible(true);
				    }
				   
				    
				st1.close();
			    con1.close();
				}	
			    catch(Exception ae)
					{
						ae.printStackTrace();
					}
				
			
			}
		});
		
		
		
	}
}
