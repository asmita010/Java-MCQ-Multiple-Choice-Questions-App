import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import java.awt.SystemColor;

public class Question {

	JFrame frame;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Question window = new Question();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Question() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(0, 0,1370, 730);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 1368, 692);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel label = new JLabel("Questions");
		label.setForeground(new Color(255, 255, 153));
		label.setFont(new Font("SansSerif", Font.PLAIN, 25));
		label.setBounds(325, 161, 146, 34);
		panel.add(label);
		
		JLabel lblNewLabel_4 = new JLabel("and Click on Button.");
		lblNewLabel_4.setForeground(Color.WHITE);
		lblNewLabel_4.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 24));
		lblNewLabel_4.setBounds(804, 219, 328, 20);
		panel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_3 = new JLabel("Select Question from List\r\n");
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 24));
		lblNewLabel_3.setBounds(804, 173, 352, 35);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon(Question.class.getResource("/image/pencil-icon (1).png")));
		lblNewLabel_2.setBounds(1148, 511, 127, 137);
		panel.add(lblNewLabel_2);
		
		JButton b3 = new JButton("Add Question");
		b3.setForeground(new Color(0, 0, 0));
		b3.setFont(new Font("David", Font.BOLD, 21));
		b3.setIcon(new ImageIcon(Question.class.getResource("/image/Button-Add-icon.png")));
		b3.setBounds(837, 553, 215, 43);
		panel.add(b3);
		
		JButton b2 = new JButton("Delete Question");
		b2.setForeground(new Color(0, 0, 0));
		b2.setFont(new Font("David", Font.BOLD, 21));
		b2.setIcon(new ImageIcon(Question.class.getResource("/image/Button-Close-icon.png")));
		b2.setBounds(837, 416, 215, 43);
		panel.add(b2);
		
		JButton b1 = new JButton("Change Question");
		b1.setForeground(new Color(0, 0, 0));
		b1.setFont(new Font("David", Font.BOLD, 21));
		b1.setIcon(new ImageIcon(Question.class.getResource("/image/Button-Next-icon.png")));
		b1.setBounds(837, 287, 230, 43);
		panel.add(b1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(77, 218, 646, 445);
		panel.add(scrollPane);
		
		JList list = new JList();
		list.setFont(new Font("Tahoma", Font.PLAIN, 20));
		list.setForeground(new Color(85, 107, 47));
		list.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		list.setBackground(new Color(224, 255, 255));
		scrollPane.setViewportView(list);
		
		JButton b = new JButton("Show Questions");
		b.setForeground(new Color(165, 42, 42));
		b.setFont(new Font("David", Font.BOLD, 21));
		b.setIcon(new ImageIcon(Question.class.getResource("/image/Start-Menu-Search-icon.png")));
		b.setBounds(954, 84, 225, 42);
		panel.add(b);
		
		JComboBox c = new JComboBox();
		c.setFont(new Font("Tahoma", Font.PLAIN, 20));
		c.setBackground(SystemColor.controlHighlight);
		c.setBounds(261, 91, 618, 35);
		panel.add(c);
		
		JLabel lblNewLabel_1 = new JLabel("Select Exam");
		lblNewLabel_1.setBackground(Color.WHITE);
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 30));
		lblNewLabel_1.setBounds(27, 90, 196, 36);
		panel.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("Go Back to Main Page");
		
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnNewButton.setIcon(new ImageIcon(Question.class.getResource("/image/go-back-icon (1).png")));
		btnNewButton.setBounds(10, 11, 260, 40);
		panel.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(Question.class.getResource("/image/imgonline-com-ua-resize-CoDsdEXtEM0mx.jpg")));
		lblNewLabel.setBounds(0, 0, 1347, 692);
		panel.add(lblNewLabel);
	

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st=con.createStatement();
			String sql = "select examname from mexam";
			ResultSet r=st.executeQuery(sql);
			
		    while (r.next()){
			c.addItem(r.getString(1));
		    }
		    st.close();
		    con.close();
		    }
			catch(Exception e)
			{
				e.printStackTrace();
			}
		try {
			 String a = (String) c.getItemAt(c.getSelectedIndex());
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st1=con1.createStatement();
			String sql = "select actualquestion from mquestion q,mexam e where q.examid=e.examid and examname='"+a+"'";
			ResultSet r=st1.executeQuery(sql);
			DefaultListModel dlm=new DefaultListModel();
		    while (r.next()){
			dlm.addElement(r.getString(1));
		    }
		    list.setModel(dlm);
		    
		st1.close();
	    con1.close();
		}	
	    catch(Exception e)
			{
				e.printStackTrace();
			}
	
			
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
					 String a = (String) c.getItemAt(c.getSelectedIndex());
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con3=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
					Statement st3=con3.createStatement();
					String sql = "select actualquestion from mquestion q,mexam e where q.examid=e.examid and examname='"+a+"'";
					
					ResultSet r=st3.executeQuery(sql);
					DefaultListModel dlm=new DefaultListModel();
				    while (r.next()){
					dlm.addElement(r.getString(1));
				
				    }
				    list.setModel(dlm);
				    st3.close();
				    con3.close();
				    }
					catch(Exception ea)
					{
						ea.printStackTrace();
					}
			}
		});
		
		
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				  String s = (String) list.getSelectedValue();
					 String a="Please Select A Question!!";
					  if (s==null)
							  {
						  JOptionPane.showMessageDialog(frame,a, "Select A Question", JOptionPane.ERROR_MESSAGE);
							  }
					  else {
				  String m=JOptionPane.showInputDialog(frame,  "Change Question  '"+s+"'", JOptionPane.QUESTION_MESSAGE);
				  if(m==null)
				  {
					  return;
				  }
				  else
				  {
				  try {
						Class.forName("oracle.jdbc.driver.OracleDriver");
						Connection con4=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
						String sql = "update mquestion set actualquestion='"+m+"' where actualquestion='"+s+"'";
						PreparedStatement sta4=con4.prepareStatement(sql);
						int count=sta4.executeUpdate();
						
						sta4.close();
					    con4.close();
					    }
						catch(Exception ea)
						{
							ea.printStackTrace();
						}
				  try {
						
						 String g = (String) c.getItemAt(c.getSelectedIndex());
						Class.forName("oracle.jdbc.driver.OracleDriver");
						Connection con3=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
						Statement st3=con3.createStatement();
						String sql = "select actualquestion from mquestion q,mexam e where q.examid=e.examid and examname='"+g+"'";
						
						ResultSet r=st3.executeQuery(sql);
						DefaultListModel dlm=new DefaultListModel();
					    while (r.next()){
						dlm.addElement(r.getString(1));
					
					    }
					    list.setModel(dlm);
					    st3.close();
					    con3.close();
					    }
						catch(Exception ea)
						{
							ea.printStackTrace();
						}
				  
					  }
					  } 
			}
			});
		
		
		
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 String s = (String) list.getSelectedValue();
				 String a="Please Select A Question!!";
				  if (s==null)
						  {
					  JOptionPane.showMessageDialog(frame,a, "Select A Question", JOptionPane.ERROR_MESSAGE);
						  }
				  else {
				int result = JOptionPane.showConfirmDialog(frame,"OPTIONS will also be deleted from Question '"+s+"'  ", "Delete Question and it's Options",
			               JOptionPane.YES_NO_OPTION,
			               JOptionPane.ERROR_MESSAGE);
				
				if(result == JOptionPane.YES_OPTION){
		                try {
						Class.forName("oracle.jdbc.driver.OracleDriver");
						Connection con6=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
						Connection con7=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
						String q="delete from mquestion where actualquestion='"+s+"'";
						String query="delete from moption where questionid in(select questionid from mquestion where actualquestion='"+s+"')";
						
						

						//String query="insert into muser values(smuser.nextval,'"+s1+"','"+s2+"','"+s3+"','"+role+"')";
						
						PreparedStatement sta6=con6.prepareStatement(query);
						PreparedStatement stat7=con7.prepareStatement(q);
				
						
						int c=sta6.executeUpdate();
						int co=stat7.executeUpdate();

						sta6.close();
					    con6.close();
					    stat7.close();
					    con7.close();
					    }
						catch(Exception ea)
						{
							ea.printStackTrace();
						}
	           
	            }
			   
				 try {
						
					 String g = (String) c.getItemAt(c.getSelectedIndex());
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con3=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
					Statement st3=con3.createStatement();
					String sql = "select actualquestion from mquestion q,mexam e where q.examid=e.examid and examname='"+g+"'";
					
					ResultSet r=st3.executeQuery(sql);
					DefaultListModel dlm=new DefaultListModel();
				    while (r.next()){
					dlm.addElement(r.getString(1));
					
				    }
				    list.setModel(dlm);
				    st3.close();
				    con3.close();
				    }
					catch(Exception ea)
					{
						ea.printStackTrace();
					}
			  
				  }
			 
	           
				  
				  }
			
		});
		
	
	
	
	
	
	
	
		b3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String a = (String) c.getItemAt(c.getSelectedIndex());
				String m=JOptionPane.showInputDialog(frame, "Enter Question to be entered in  '"+a+"'");  
			    if(m==null)
			    {
			    	return;
			    }
			    else
			    {
				try
			     {
			     String url="jdbc:oracle:thin:@localhost:1521:xe";
					String username="username";
					String password="password";
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con9 = DriverManager.getConnection(url,username,password);

					String query="insert into mquestion values(smquestionid.nextval,'"+m+"',(select examid from mexam where examname='"+a+"'),null)";   
					PreparedStatement sta9=con9.prepareStatement(query);
					int count=sta9.executeUpdate();
					sta9.close();
				    con9.close();
				}
			     catch(Exception ea)
			     {
			    	 ea.printStackTrace();
			     }
			     try {
						
					 String g = (String) c.getItemAt(c.getSelectedIndex());
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con3=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
					Statement st3=con3.createStatement();
					String sql = "select actualquestion from mquestion q,mexam e where q.examid=e.examid and examname='"+g+"'";
					
					ResultSet r=st3.executeQuery(sql);
					DefaultListModel dlm=new DefaultListModel();
				    while (r.next()){
					dlm.addElement(r.getString(1));
					
				    }
				    list.setModel(dlm);
				    st3.close();
				    con3.close();
				    }
					catch(Exception ea)
					{
						ea.printStackTrace();
					}
			  
			    }
			 
			}
			
		});
		
	
	
	
		
	
		c.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					 String a = (String) c.getItemAt(c.getSelectedIndex());
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
					Statement st1=con1.createStatement();
					String sql = "select actualquestion from mquestion q,mexam e where q.examid=e.examid and examname='"+a+"'";
					ResultSet r=st1.executeQuery(sql);
					DefaultListModel dlm=new DefaultListModel();
				    while (r.next()){
					dlm.addElement(r.getString(1));
				    }
				    list.setModel(dlm);
				    
				st1.close();
			    con1.close();
				}	
			    catch(Exception ge)
					{
						ge.printStackTrace();
					}
			}
		});
		
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				Ones2 ong=new Ones2();
				ong.frame1.setVisible(true);
			}
			
		});
		
		
		
		

	}
}
