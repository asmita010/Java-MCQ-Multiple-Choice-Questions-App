import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTable;


import net.proteanit.sql.DbUtils;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Color;
import java.awt.Component;

public class ones3 {

	 JFrame frame;
	 JTable table;
	 private final JLabel lblNewLabel = new JLabel("");

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ones3 window = new ones3();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public ones3() {
		initialize();
	}

	
	
	 void initialize() {
		 frame = new JFrame();
			frame.setBounds(0, 0,1370, 730);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.getContentPane().setLayout(null);
			
			JButton back = new JButton("Redirect to main page");
			back.setForeground(new Color(0, 51, 153));
			back.setFont(new Font("Arial Narrow", Font.BOLD, 18));
			back.setIcon(new ImageIcon(ones3.class.getResource("/image/go-back-icon (1).png")));
			back.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					frame.dispose();
					Ones2 j =new Ones2();
					j.frame1.setVisible(true);
				}
			});
			
			JScrollPane scrollPane = new JScrollPane();
			scrollPane.setBounds(68, 193, 1217, 467);
			frame.getContentPane().add(scrollPane);
			

			table = new JTable();
			table.setFont(new Font("Tahoma", Font.PLAIN, 15));
			table.setColumnSelectionAllowed(true);
			table.setCellSelectionEnabled(true);
			table.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
			table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
			table.setRowHeight(20);
			scrollPane.setViewportView(table);
			

			
			
			
			back.setBounds(23, 23, 225, 30);
			frame.getContentPane().add(back);
			
			JPanel panel = new JPanel();
			panel.setBounds(0, 0, 1354, 692);
			frame.getContentPane().add(panel);
			panel.setLayout(null);
			
			JLabel lblNewLabel_3 = new JLabel("Questions");
			lblNewLabel_3.setForeground(new Color(176, 224, 230));
			lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 27));
			lblNewLabel_3.setBounds(800, 76, 150, 29);
			panel.add(lblNewLabel_3);
			
			JLabel lblNewLabel_2 = new JLabel("Exams");
			lblNewLabel_2.setForeground(new Color(176, 224, 230));
			lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 27));
			lblNewLabel_2.setBounds(147, 75, 89, 30);
			panel.add(lblNewLabel_2);

			JComboBox question = new JComboBox();
			question.setFont(new Font("Tahoma", Font.BOLD, 15));
			question.setBounds(628, 123, 513, 30);
			panel.add(question);
			JComboBox exam = new JComboBox();
			exam.setFont(new Font("Tahoma", Font.BOLD, 15));
			exam.setBounds(45, 123, 332, 30);
			panel.add(exam);
			
			JButton viewq = new JButton("View Questions");
			viewq.setBounds(406, 120, 173, 33);
			panel.add(viewq);
			viewq.setFont(new Font("Arial Narrow", Font.BOLD, 18));
			viewq.setIcon(new ImageIcon(ones3.class.getResource("/image/Search-icon (2).png")));
			
			
			JButton viewo = new JButton("View Options");
			viewo.setBounds(1176, 120, 168, 33);
			panel.add(viewo);
			viewo.setFont(new Font("Arial Narrow", Font.BOLD, 18));
			viewo.setIcon(new ImageIcon(ones3.class.getResource("/image/Search-icon (2).png")));
			
			viewq.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					try {
						String a = (String) exam.getItemAt(exam.getSelectedIndex());
						
						
						Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
						Statement st=con.createStatement();
						
						String sql = "select actualquestion from mquestion,mexam where mquestion.examid= mexam.examid and examname='"+ a +"'";
						   
	 					ResultSet r=st.executeQuery(sql);
						table.setModel(DbUtils.resultSetToTableModel(r));
						
						question.removeAllItems();
						Statement s=con.createStatement();
						String sql1="select * from mquestion,mexam where mquestion.examid= mexam.examid and examname='"+ a +"'";
						ResultSet rss=st.executeQuery(sql1);

					    while (rss.next()){
						
						question.addItem(rss.getString(2));
						
						}
					    }
						catch(Exception e)
						{
							e.printStackTrace();
						}
					
				}
				
			});
			
		
			lblNewLabel.setFont(new Font("Arial Narrow", Font.BOLD, 18));
			lblNewLabel.setIcon(new ImageIcon(ones3.class.getResource("/image/imgonline-com-ua-resize-CoDsdEXtEM0mx.jpg")));
			lblNewLabel.setBounds(0, 0, 1354, 692);
			panel.add(lblNewLabel);
			
		
			viewo.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
	               try {
						
						
						Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
						Statement st=con.createStatement();
						
						String b=(String) question.getSelectedItem(); 
						
						
						String sql = "select actualoptions from mquestion,moption where mquestion.questionid =moption.questionid and actualquestion='"+ b +"'";
		
						ResultSet r=st.executeQuery(sql);
						table.setModel(DbUtils.resultSetToTableModel(r));
						
						}
						catch(Exception e)
						{
							e.printStackTrace();
						}
						
				}
				
			});
			
			
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
				Statement st=con.createStatement();
				ResultSet rs=st.executeQuery("select * from mexam"); 

			    while (rs.next()){
				
				exam.addItem(rs.getString(2));
			
				
			    }
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}

			
	
	}
}
