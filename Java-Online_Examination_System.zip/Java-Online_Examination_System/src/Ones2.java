import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Ones2 {

	 JFrame frame1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ones2 window = new Ones2();
					window.frame1.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	}
	
	/**
	 * Create the application.
	 */
	public Ones2() {
		
	
	
	
		frame1 = new JFrame();
		frame1.setBounds(0, 0,1370, 730);
		frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame1.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 1354, 692);
		frame1.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(227, 81, 900, 531);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JButton btnNewButton = new JButton("View Contents");
		
		btnNewButton.setForeground(new Color(0, 0, 139));
		btnNewButton.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 20));
		btnNewButton.setBounds(210, 175, 173, 44);
		panel_1.add(btnNewButton);
		
		JLabel lblNewLabel_2 = new JLabel("Logged in as Admin");
		lblNewLabel_2.setForeground(new Color(70, 130, 180));
		lblNewLabel_2.setFont(new Font("Maiandra GD", Font.BOLD, 38));
		lblNewLabel_2.setBounds(247, 51, 388, 57);
		panel_1.add(lblNewLabel_2);
		
		
		
		
		JButton btnNewButton_3 = new JButton("Modify Exams");
		
		btnNewButton_3.setForeground(new Color(139, 0, 0));
		btnNewButton_3.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 20));
		btnNewButton_3.setBounds(55, 310, 170, 44);
		
		
		JButton btnNewButton_4 = new JButton("Modify Questions");
		
		btnNewButton_4.setForeground(new Color(139, 0, 0));
		btnNewButton_4.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 20));
		btnNewButton_4.setBounds(336, 310, 200, 44);
		
		JButton btnNewButton_5 = new JButton("Modify Options");
		
		btnNewButton_5.setForeground(new Color(139, 0, 0));
		btnNewButton_5.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 20));
		btnNewButton_5.setBounds(644, 310, 180, 44);
		
		
		panel_1.add(btnNewButton_3);
		panel_1.add(btnNewButton_4);
		panel_1.add(btnNewButton_5);
		
		JLabel lblNewLabel_3 = new JLabel("New label");
		lblNewLabel_3.setIcon(new ImageIcon(Ones2.class.getResource("/image/Stock Image_ Signs_Symbols.jpg")));
		lblNewLabel_3.setBounds(595, 418, 229, 102);
		panel_1.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setIcon(new ImageIcon(Ones2.class.getResource("/image/test-icon (2).png")));
		lblNewLabel_4.setBounds(698, 11, 117, 128);
		panel_1.add(lblNewLabel_4);
		
		JButton btnViewResults = new JButton("View Results");
		btnViewResults.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame1.dispose();
				Result r =new Result();
				r.frame.setVisible(true);
			}
		});
		btnViewResults.setForeground(new Color(0, 0, 139));
		btnViewResults.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 20));
		btnViewResults.setBounds(526, 175, 173, 44);
		panel_1.add(btnViewResults);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(Ones2.class.getResource("/image/75Z2XU.jpg")));
		lblNewLabel.setBounds(0, 0, 1354, 692);
		panel.add(lblNewLabel);
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame1.dispose();
				ones3 o=new ones3();
				o.frame.setVisible(true);
			}
		});
		
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame1.dispose();
				Exam m=new Exam();
				m.frame.setVisible(true);
			}
		});	
		
		
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame1.dispose();
				Question q=new Question();
				q.frame.setVisible(true);
			}
		});
		
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame1.dispose();
				Option p=new Option();
				p.frame.setVisible(true);
			}
		});
		
		
		}
	}
	


