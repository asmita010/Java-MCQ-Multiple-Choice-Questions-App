import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JComboBox;
import javax.swing.JTable;

import net.proteanit.sql.DbUtils;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
import javax.swing.border.BevelBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JScrollPane;

public class Result {

 JFrame frame;
	 JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Result window = new Result();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Result() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(0, 0,1362 , 730);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(80, 57, 1185, 577);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Select Exam");
		lblNewLabel_1.setForeground(new Color(51, 0, 153));
		lblNewLabel_1.setFont(new Font("Trebuchet MS", Font.BOLD, 22));
		lblNewLabel_1.setBounds(95, 125, 161, 29);
		panel.add(lblNewLabel_1);
		
		JComboBox c = new JComboBox();
		c.setForeground(new Color(0, 0, 153));
		c.setFont(new Font("Tahoma", Font.PLAIN, 17));
		c.setBounds(302, 126, 325, 28);
		panel.add(c);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(91, 183, 1003, 332);
		panel.add(scrollPane);
		
		table = new JTable();
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		table.setForeground(new Color(0, 0, 0));
		scrollPane.setViewportView(table);
		table.setRowHeight(28);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
			}
		));
		table.setFont(new Font("Tahoma", Font.PLAIN, 18));
		
		JButton btnNewButton = new JButton("Show Results");
		btnNewButton.setIcon(new ImageIcon(Result.class.getResource("/image/Search-icon (2).png")));
		btnNewButton.setForeground(SystemColor.textHighlight);
		btnNewButton.setFont(new Font("Andalus", Font.BOLD, 18));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 try {
						
						
						Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
						Statement st=con.createStatement();
						
						String b=(String) c.getSelectedItem(); 
						
						
						String sql = "select username,score from muser u,mresult r,mexam e where u.userid =r.userid and e.examid=r.examid and examname='"+ b +"' and username in (select username from muser where userid=r.userid )";
		
						ResultSet r=st.executeQuery(sql);
						table.setModel(DbUtils.resultSetToTableModel(r));
						
						}
						catch(Exception e)
						{
							e.printStackTrace();
						}
				
				
			}
		});
		btnNewButton.setBounds(705, 124, 174, 34);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Go Back To Main Page");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Ones2 o=new Ones2();
				frame.dispose();
				o.frame1.setVisible(true);
			}
			
		});
		btnNewButton_1.setIcon(new ImageIcon(Result.class.getResource("/image/go-back-icon (1).png")));
		btnNewButton_1.setForeground(new Color(0, 102, 204));
		btnNewButton_1.setFont(new Font("Traditional Arabic", Font.BOLD, 20));
		btnNewButton_1.setBounds(41, 26, 278, 34);
		panel.add(btnNewButton_1);
		
		
		
		JButton btnNewButton_2 = new JButton("Send Mail");
		btnNewButton_2.setForeground(new Color(0, 102, 153));
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
int x=table.getSelectedRow();
				
				String u=(String) table.getValueAt(x, 0);
				
				try {
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
					Statement st=con.createStatement();
					String sql = "select userid from muser where username='"+u+"'";
					ResultSet r=st.executeQuery(sql);
					
				    while (r.next()){
				    	
				    	
					
				    	String id=r.getString(1);

							Class.forName("oracle.jdbc.driver.OracleDriver");
							Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
							Statement st1=con1.createStatement();
							String sql1 = "select email from muser where userid='"+id+"'";

							ResultSet r1=st1.executeQuery(sql1);
							
						    while (r1.next()){
						    	String e=r1.getString(1);


									
									
									Connection con2=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
									Statement st2=con2.createStatement();
									
									
									
									
									String sql2 = "select score from mresult where userid='"+id+"' ";
					
									ResultSet r2=st2.executeQuery(sql2);
									 while (r2.next()){
										 String sc=r2.getString(1);
										 String b=(String) c.getSelectedItem(); 
										    Mailer.send("***","***",e,"Results Of "+b,"You got '"+sc+"' in "+b);  
				                            JOptionPane.showMessageDialog(frame, "Mail sent successfully");

									}
									  st2.close();
									   con2.close();
						    	}
									
						    st1.close();
							   con1.close();
						    	
						    	
						    	
						
						
				    }
				    st.close();
					   con.close();
				}
					catch(Exception ea)
					{
						ea.printStackTrace();
					}
				
		
		}
		});
		btnNewButton_2.setBounds(947, 67, 133, 29);
		panel.add(btnNewButton_2);
		
		JLabel lblNewLabel_2 = new JLabel("Select\r\n the Students From the Table");
		lblNewLabel_2.setFont(new Font("Arial Unicode MS", Font.PLAIN, 18));
		lblNewLabel_2.setBounds(855, 11, 289, 23);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("to send Emails on their R\r\negistered Accounts");
		lblNewLabel_3.setFont(new Font("Arial Unicode MS", Font.PLAIN, 18));
		lblNewLabel_3.setBounds(821, 31, 354, 29);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(0, 0, 1346, 692);
		lblNewLabel.setIcon(new ImageIcon(Result.class.getResource("/image/75Z2XU.jpg")));
		frame.getContentPane().add(lblNewLabel);
		

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st=con.createStatement();
			String sql = "select examname from mexam";
			ResultSet r=st.executeQuery(sql);
			
		    while (r.next()){
			c.addItem(r.getString(1));
		    }
		   st.close();
		   con.close();
		    }
			catch(Exception e)
			{
				e.printStackTrace();
			}
	
		
	}
}
