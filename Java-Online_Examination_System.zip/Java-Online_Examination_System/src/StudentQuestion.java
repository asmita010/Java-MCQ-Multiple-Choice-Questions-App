import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.DefaultListModel;

import java.awt.BorderLayout;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.Timer;
import javax.swing.AbstractListModel;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.JScrollPane;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import java.awt.Component;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class StudentQuestion {

	 JFrame frame;
	 JRadioButton rdbtnNewRadioButton,rdbtnNewRadioButton_1,rdbtnNewRadioButton_2,rdbtnNewRadioButton_3; 
	 JLabel lblNewLabel,lblNewLabel_1;
	 JButton next;
	 JButton btnNewButton;
	 int index;
	 private JTextField textField;
	 ButtonGroup g;	
	int seconds=20;
	int total,i;
	int time=0;
	int k;
	String h;
	int corr,click;
	Vector<String> v2 = new Vector<String>();
	Vector<String> v3 = new Vector<String>();
	Vector<String> v5 = new Vector<String>();
	Vector<String> notans = new Vector<String>();
	JLabel lblNewLabel_2=new JLabel();
	int t;
	
	Timer timer;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentQuestion window = new StudentQuestion(0,null, 0);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */

			public StudentQuestion(int st,String exn,int t) {
	int studid=st;
	String examname=exn;
	 time=t;
		
        	
	
						 timer = new Timer(60000, new ActionListener() {
		
			@Override
							public void actionPerformed(ActionEvent e) {
				time=time-1;
            	lblNewLabel_2.setText(String.valueOf(time));

        		
				                       if(time==0) {
				                              	timer.stop();
					                            frame.dispose();
					                            JOptionPane.showMessageDialog(frame, "You got:"+corr);
					                            try
											     {
											     String url="jdbc:oracle:thin:@localhost:1521:xe";
													String username="username";
													String password="password";
													Class.forName("oracle.jdbc.driver.OracleDriver");
													Connection con9 = DriverManager.getConnection(url,username,password);

													String query="insert into mresult values(smresultid.nextval,'"+studid+"','"+corr+"',(select examid from mexam where examname='"+examname+"'))";   
													PreparedStatement sta9=con9.prepareStatement(query);
													int count=sta9.executeUpdate();
													sta9.close();
												    con9.close();
												}
											     catch(Exception ea)
											     {
											    	 ea.printStackTrace();
											     }
					
				                       }
					}
				});
				        	

				timer.start();
		
	        

		
				 String ti = Integer.toString(time); 
		initialize(ti);
		lblNewLabel_1.setText(examname);
		index=0;
		Vector<String> v = new Vector<String>();
		try {
			 
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st1=con1.createStatement();
			String sql = "select actualquestion from mquestion q,mexam e where q.examid=e.examid and examname='"+examname+"'";
			ResultSet r=st1.executeQuery(sql);
			
		    while (r.next()){
			
			v.add(r.getString(1));
			
		    
		    }
		    
		    
		st1.close();
	    con1.close();
		}	
	    catch(Exception e)
			{
				e.printStackTrace();
			}
		total=v.size();
	
	
		
		String j=v.get(index);
		textField.setText(1+". "+j);
		Vector<String> v1 = new Vector<String>();
		try {
			 
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st1=con1.createStatement();
			String sql = "select actualoptions from mquestion q,moption o where q.questionid=o.questionid and actualquestion='"+j+"'";
			ResultSet r=st1.executeQuery(sql);
			
		    while (r.next()){
			
			v1.add(r.getString(1));
			
		    
		    }
		  
		   
		    
		st1.close();
	    con1.close();
		}	
	    catch(Exception e)
			{
				e.printStackTrace();
			}
		
		rdbtnNewRadioButton.setText(v1.get(0));
		rdbtnNewRadioButton_1.setText(v1.get(1));
		rdbtnNewRadioButton_2.setText(v1.get(2));
		rdbtnNewRadioButton_3.setText(v1.get(3));
		
		
		 next.addActionListener(new ActionListener() {
			 	public void actionPerformed(ActionEvent e) {
			 		if(index==0)
			 			{
			 			checkans(v,index);
			 			index++;
			 			g.clearSelection();
			 			display(v,index);

			 			}
			 		
			 		else if(index==total-1)
			 		{
			 			
			 		
			 			click++;
			 		
				 		 Vector notans=checkans(v,index);
				 			
			 				
				 			if(notans.isEmpty())
				 				{
								JOptionPane.showMessageDialog(frame, "Result:You got "+corr);
								frame.dispose();
								try
							     {
							     String url="jdbc:oracle:thin:@localhost:1521:xe";
									String username="username";
									String password="password";
									Class.forName("oracle.jdbc.driver.OracleDriver");
									Connection con9 = DriverManager.getConnection(url,username,password);

									String query="insert into mresult values(smresultid.nextval,'"+studid+"','"+corr+"',(select examid from mexam where examname='"+examname+"'))";   
									PreparedStatement sta9=con9.prepareStatement(query);
									int count=sta9.executeUpdate();
									sta9.close();
								    con9.close();
								}
							     catch(Exception ea)
							     {
							    	 ea.printStackTrace();
							     }
								
								
								
								frame.dispose();
								
								
								
								
				 				}
				 			else
				 				next(notans,click,examname,studid,examname);
				 		
				 			g.clearSelection();
		 			
		 			
			 			
			 		}
			 		else
			 		{
			 			
			 			checkans(v,index);
			 			index++;
g.clearSelection();
			 			display(v,index);

			 		}

			 	}
			 });

		 btnNewButton.addActionListener(new ActionListener() {
			 	public void actionPerformed(ActionEvent e) {
			 		JOptionPane.showMessageDialog(frame, "Result:You got "+corr);
			 		try
				     {
				     String url="jdbc:oracle:thin:@localhost:1521:xe";
						String username="username";
						String password="password";
						Class.forName("oracle.jdbc.driver.OracleDriver");
						Connection con9 = DriverManager.getConnection(url,username,password);

						String query="insert into mresult values(smresultid.nextval,'"+studid+"','"+corr+"',(select examid from mexam where examname='"+examname+"'))";   
						PreparedStatement sta9=con9.prepareStatement(query);
						int count=sta9.executeUpdate();
						sta9.close();
					    con9.close();
					}
				     catch(Exception ea)
				     {
				    	 ea.printStackTrace();
				     }
			 		frame.dispose();
			 	}
			 });
	
	}

	

	private void initialize(String t) {
		
		frame = new JFrame();
		frame.setBounds(0, 0,1362 , 730);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(92, 65, 1161, 562);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		 rdbtnNewRadioButton = new JRadioButton("New radio button");
		rdbtnNewRadioButton.setFont(new Font("Times New Roman", Font.BOLD, 23));
		rdbtnNewRadioButton.setBounds(10, 177, 1117, 35);
		panel.add(rdbtnNewRadioButton);
		
		 rdbtnNewRadioButton_1 = new JRadioButton("New radio button");
		rdbtnNewRadioButton_1.setFont(new Font("Times New Roman", Font.BOLD, 23));
		rdbtnNewRadioButton_1.setBounds(10, 237, 1141, 40);
		panel.add(rdbtnNewRadioButton_1);
		
		 rdbtnNewRadioButton_2 = new JRadioButton("New radio button");
		rdbtnNewRadioButton_2.setFont(new Font("Times New Roman", Font.BOLD, 23));
		rdbtnNewRadioButton_2.setBounds(6, 306, 1131, 35);
		panel.add(rdbtnNewRadioButton_2);
		
		 rdbtnNewRadioButton_3 = new JRadioButton("New radio button");
		rdbtnNewRadioButton_3.setFont(new Font("Times New Roman", Font.BOLD, 23));
		rdbtnNewRadioButton_3.setBounds(6, 378, 1145, 35);
		panel.add(rdbtnNewRadioButton_3);
		
		 next = new JButton("Next Question");
		 next.setFont(new Font("Segoe UI", Font.BOLD, 20));
		
		next.setBounds(482, 424, 204, 35);
		panel.add(next);
		
		 lblNewLabel_1 = new JLabel("");
		 lblNewLabel_1.setAlignmentX(Component.CENTER_ALIGNMENT);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_1.setBounds(433, 18, 496, 37);
		panel.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setFont(new Font("Lucida Fax", Font.BOLD, 20));
		textField.setEditable(false);
		textField.setBounds(10, 66, 1141, 72);
		panel.add(textField);
		textField.setColumns(10);
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setFont(new Font("Arial Black", Font.BOLD, 26));
		lblNewLabel.setBounds(0, 0, 1346, 692);
		lblNewLabel.setIcon(new ImageIcon(StudentQuestion.class.getResource("/image/75Z2XU.jpg")));
		frame.getContentPane().add(lblNewLabel);
		
		g = new ButtonGroup();
		g.add(rdbtnNewRadioButton);
		g.add(rdbtnNewRadioButton_1);
		g.add(rdbtnNewRadioButton_2);
		g.add(rdbtnNewRadioButton_3);
		
		lblNewLabel_2 = new JLabel(t);
		lblNewLabel_2.setFont(new Font("Gill Sans MT Condensed", Font.BOLD, 26));
		lblNewLabel_2.setBounds(1031, 11, 96, 43);
		panel.add(lblNewLabel_2);
		
		 btnNewButton = new JButton("Submit");
		btnNewButton.setFont(new Font("Microsoft Sans Serif", Font.BOLD, 23));
		btnNewButton.setBounds(516, 493, 143, 35);
		panel.add(btnNewButton);
		
		JLabel lblNewLabel_3 = new JLabel("Timer:");
		lblNewLabel_3.setFont(new Font("Gill Sans MT", Font.BOLD, 20));
		lblNewLabel_3.setBounds(952, 11, 86, 35);
		panel.add(lblNewLabel_3);
		
		
		
	}
	
	
	
	
	
	Vector<String> checkans(Vector v,int i)
	{
		int index=i;
		Vector question=v;
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con2=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
		Statement st2=con2.createStatement();
		String sql = "select answer from mquestion where actualquestion='"+question.get(index)+"'";
		ResultSet r2=st2.executeQuery(sql);
		
	    while (r2.next()){
		
		String a=r2.getString(1);
	    if (rdbtnNewRadioButton.isSelected())
		{
		h=rdbtnNewRadioButton.getText();
		if (a.equals(h))
			corr++;
		}
	else if (rdbtnNewRadioButton_1.isSelected())
	{
		h=rdbtnNewRadioButton_1.getText();
		if (a.equals(h))
			corr++;
	}
	else if (rdbtnNewRadioButton_2.isSelected())
	{
		h=rdbtnNewRadioButton_2.getText();
		if (a.equals(h))
			corr++;
	}
	else if (rdbtnNewRadioButton_3.isSelected())
		{
		h=rdbtnNewRadioButton_3.getText();
		if (a.equals(h))
			corr++;
		}
	else {
		h=null;
	    
	    v3.add((String) v.get(index));

	    }
	 
	}
	    r2.close();  
		st2.close();
	    con2.close();
	}
    catch(Exception e)
		{
			e.printStackTrace();
		}
	
	
	
	
		
		return v3;
	}
	
	
	
	
	
	
	int display(Vector v,int i)
	{
		int index=i;
		Vector question=v;
		String j=(String) question.get(index);
		
		textField.setText((index+1)+". "+j);
		
		Vector<String> option = new Vector<String>();
		try {
			 
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st1=con1.createStatement();
			String sql = "select actualoptions from mquestion q,moption o where q.questionid=o.questionid and actualquestion='"+j+"'";
			ResultSet r=st1.executeQuery(sql);
			
		    while (r.next()){
			
			option.add(r.getString(1));
			
		    
		    }
		   
		r.close();    
		st1.close();
	    con1.close();
		}	
	    catch(Exception e)
			{
				e.printStackTrace();
			}
		
		rdbtnNewRadioButton.setText(option.get(0));
		rdbtnNewRadioButton_1.setText(option.get(1));
		rdbtnNewRadioButton_2.setText(option.get(2));
		rdbtnNewRadioButton_3.setText(option.get(3));

		
		return index;
	}
	
	
	
	
void checknotans(Vector ov,int i)
	{
	
		Vector quest=ov;
		int index=i;
		
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con2=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
		Statement st2=con2.createStatement();
		String sql = "select answer from mquestion where actualquestion='"+quest.get(index)+"'";
		ResultSet r2=st2.executeQuery(sql);
		
	    while (r2.next()){
		
		String a=r2.getString(1);
	    if (rdbtnNewRadioButton.isSelected())
		{
		h=rdbtnNewRadioButton.getText();
		if (a.equals(h))
			corr++;
		}
	else if (rdbtnNewRadioButton_1.isSelected())
	{
		h=rdbtnNewRadioButton_1.getText();
		if (a.equals(h))
			corr++;
	}
	else if (rdbtnNewRadioButton_2.isSelected())
	{
		h=rdbtnNewRadioButton_2.getText();
		if (a.equals(h))
			corr++;
	}
	else if (rdbtnNewRadioButton_3.isSelected())
		{
		h=rdbtnNewRadioButton_3.getText();
		if (a.equals(h))
			corr++;
		}
	else {
		corr=corr+0;
	    
	    

	    }
	 
	}
	    r2.close();  
		st2.close();
	    con2.close();
	}
    catch(Exception e)
		{
			e.printStackTrace();
		}
	
	
		
		
	}
	
	
	
	
	
	public int nextQ(Vector ov,int oindex,int tot)
	{
				int index;
		Vector v;
		index=oindex;
		v=ov;
		int ind;
		int total=tot;
		if(index==0)
			ind=index;
		else
		{
		ind=index-1;
		try {
			 
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con2=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st2=con2.createStatement();
			String sql = "select answer from mquestion where actualquestion='"+v.get(ind)+"'";
			ResultSet r2=st2.executeQuery(sql);
			
		    while (r2.next()){
			
			String a=r2.getString(1);
		    System.out.println("CHECK="+a);
		    if (rdbtnNewRadioButton.isSelected())
			{
			h=rdbtnNewRadioButton.getText();
			if (a.equals(h))
				corr++;
			}
		else if (rdbtnNewRadioButton_1.isSelected())
		{
			h=rdbtnNewRadioButton_1.getText();
			if (a.equals(h))
				corr++;
		}
		else if (rdbtnNewRadioButton_2.isSelected())
		{
			h=rdbtnNewRadioButton_2.getText();
			if (a.equals(h))
				corr++;
		}
		else if (rdbtnNewRadioButton_3.isSelected())
			{
			h=rdbtnNewRadioButton_3.getText();
			if (a.equals(h))
				corr++;
			}
		else {
			h=null;
		    
		    v3.add((String) v.get(ind));

		    }
		 
		}
		    r2.close();  
			st2.close();
		    con2.close();
		}
	    catch(Exception e)
			{
				e.printStackTrace();
			}
		
		}
		
		
	
				g.clearSelection();
		String j=(String) v.get(index);
		textField.setText((index+1)+". "+j);
		
		Vector<String> v1 = new Vector<String>();
		try {
			 
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st1=con1.createStatement();
			String sql = "select actualoptions from mquestion q,moption o where q.questionid=o.questionid and actualquestion='"+j+"'";
			ResultSet r=st1.executeQuery(sql);
			
		    while (r.next()){
			
			v1.add(r.getString(1));
			
		    
		    }
		   
		r.close();    
		st1.close();
	    con1.close();
		}	
	    catch(Exception e)
			{
				e.printStackTrace();
			}
		
		rdbtnNewRadioButton.setText(v1.get(0));
		rdbtnNewRadioButton_1.setText(v1.get(1));
		rdbtnNewRadioButton_2.setText(v1.get(2));
		rdbtnNewRadioButton_3.setText(v1.get(3));

		return index;
	}
	
	
	public void next(Vector s,int c,String sa,int st,String ex)
	{
		String r=sa;
		String examname=ex;
		int studid=st;
		
		Vector p=s;
		int t=p.size();
		int click=c;
	
	
	
	if(click==1)
		{		
	display(p,k);
	k++;	
	
	}
		else
		{		
			
		


				if(k>=t)
				{
					

				checknotans(p,k);
					JOptionPane.showMessageDialog(frame, "Result:You got  "+corr);
					
					try
				     {
				     String url="jdbc:oracle:thin:@localhost:1521:xe";
						String username="username";
						String password="password";
						Class.forName("oracle.jdbc.driver.OracleDriver");
						Connection con9 = DriverManager.getConnection(url,username,password);

						String query="insert into mresult values(smresultid.nextval,'"+studid+"','"+corr+"',(select examid from mexam where examname='"+examname+"'))";   
						PreparedStatement sta9=con9.prepareStatement(query);
						int count=sta9.executeUpdate();
						sta9.close();
					    con9.close();
					}
				     catch(Exception ea)
				     {
				    	 ea.printStackTrace();
				     }
					
					
					
					
					
					
					
					
					
					
				}
				else
				{
				
					checknotans(p,k-1);
					
					
				

					display(p,k);
					k++;
				}
		}
	}
	
	
	
	
	
	
	
	
	
	





void full(Vector vt)
{
	Vector v3;
	v3=vt;
	i=0;
	while(v3!=null)
	{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st1=con1.createStatement();
			String sql = "select actualquestion from mquestion where actualquestion='"+v3.get(i)+"'";
			ResultSet r=st1.executeQuery(sql);
			
		    while (r.next()){
			String j=r.getString(1);
		    	textField.setText((i+1)+". "+j);
		    
		    }
		  
		    
		    
		st1.close();
	    con1.close();
		}	
	    catch(Exception e)
			{
				e.printStackTrace();
			}
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st1=con1.createStatement();
			String sql = "select actualoptions from mquestion q,moption o where q.questionid=o.questionid and actualquestion='"+v3.get(i)+"'";
			ResultSet r=st1.executeQuery(sql);
			if(v5!=null)
				v5.removeAllElements();
		    while (r.next()){
			
		
			v5.add(r.getString(1));
			
		    
		    }
		  
		    
		st1.close();
	    con1.close();
		}	
	    catch(Exception e)
			{
				e.printStackTrace();
			}
		
		rdbtnNewRadioButton.setText(v5.get(0));
		rdbtnNewRadioButton_1.setText(v5.get(1));
		rdbtnNewRadioButton_2.setText(v5.get(2));
		rdbtnNewRadioButton_3.setText(v5.get(3));
n();
		i++;
	}
	
}
void n()
{
	next.addActionListener(new ActionListener() {
	 	public void actionPerformed(ActionEvent e) {
	 		try {
				 
				Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection con2=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
				Statement st2=con2.createStatement();
				String sql = "select answer from mquestion where actualquestion='"+v3.get(i)+"'";
				ResultSet r2=st2.executeQuery(sql);
				
			    while (r2.next()){
				
				String a=r2.getString(1);
			    System.out.println(a);
			    if (rdbtnNewRadioButton.isSelected())
				{
				h=rdbtnNewRadioButton.getText();
				if (a.equals(h))
					corr++;
				}
			else if (rdbtnNewRadioButton_1.isSelected())
			{
				h=rdbtnNewRadioButton_1.getText();
				if (a.equals(h))
					corr++;
			}
			else if (rdbtnNewRadioButton_2.isSelected())
			{
				h=rdbtnNewRadioButton_2.getText();
				if (a.equals(h))
					corr++;
			}
			else if (rdbtnNewRadioButton_3.isSelected())
				{
				h=rdbtnNewRadioButton_3.getText();
				if (a.equals(h))
					corr++;
				}
			else {
				corr=corr+0;
			    
			   

			    }
			 
			}
			    r2.close();  
				st2.close();
			    con2.close();
			}
		    catch(Exception ae)
				{
					ae.printStackTrace();
				}
			
			}
	 	
	 });
}
}

